package com.synergetics;


/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(137, "Smita", 123456);
		Employee employee2=new Employee(125, "Brijesh", 1235234);
		Address address=new Address(100, "mum","ind");
		Address address2=new Address(101, "pune","ind");
		
		ArrayList<Address> list=new ArrayList<Address>();
		list.add(address);
		list.add(address2);
		
		
		employee.setAddresses(list);
		employee2.setAddresses(list);		
		
		ArrayList<Employee> list1=new ArrayList<Employee>();
		list1.add(employee);
		list1.add(employee2);
		
		address.setEmployees(list1);
		address2.setEmployees(list1);
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(employee);
		em.persist(employee2);

		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
