package com.sbk.bi_m2m;


/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BiManyToManyDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(888 + new Random().nextInt()+11, "Smita", 35000);
		Employee employee2 = new Employee(777 + new Random().nextInt()+13, "Brijesh", 38000);
		Address address = new Address(54 + new Random().nextInt()+11, "mum", "ind");
		Address address2 = new Address(65 + new Random().nextInt()+12, "pune", "ind");
		
		ArrayList<Address> list=new ArrayList<Address>();
		list.add(address);
		list.add(address2);
		
		
		employee.setAddresses(list);
		employee2.setAddresses(list);		
		
		ArrayList<Employee> list1=new ArrayList<Employee>();
		list1.add(employee);
		list1.add(employee2);
		
		address.setEmployees(list1);
		address2.setEmployees(list1);
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(employee);
		em.persist(employee2);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
