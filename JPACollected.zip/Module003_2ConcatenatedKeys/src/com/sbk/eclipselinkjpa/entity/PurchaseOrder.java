package com.sbk.eclipselinkjpa.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
@Table(name = "PURCHASEORDERS")
public class PurchaseOrder {
	@Id 
	@GeneratedValue
	private int id;
	  private Date orderDate;
	  private double orderAmount;
	  private String itemName;
	@Embedded 
	  @AttributeOverrides({
		  @AttributeOverride(name = "street", column = @Column(name = "Street")),
	      @AttributeOverride(name = "city", column = @Column(name = "City")),
	      @AttributeOverride(name = "state", column = @Column(name = "PROVINCE")),
	      @AttributeOverride(name = "zip", column = @Column(name = "zip"))
	  })
	  private BillingAddress address;
	
	public PurchaseOrder() {
		super();
	}

	public PurchaseOrder(int id, Date orderDate, double orderAmount, String itemName, BillingAddress address) {
		super();
		this.id = id;
		this.orderDate = orderDate;
		this.orderAmount = orderAmount;
		this.itemName = itemName;
		this.address = address;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public double getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(double orderAmount) {
		this.orderAmount = orderAmount;
	}
	public BillingAddress getAddress() {
		return address;
	}
	public void setAddress(BillingAddress address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "PurchaseOrder [id=" + id + ", orderDate=" + orderDate + ", orderAmount=" + orderAmount + ", itemName="
				+ itemName + ", address=" + address + "]";
	}
	
}