package com.sbk.eclipselinkjpa.service;

import java.util.Calendar;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.sbk.eclipselinkjpa.entity.BillingAddress;
import com.sbk.eclipselinkjpa.entity.PurchaseOrder;

public class PurchaseApp 
{
	@SuppressWarnings({ "deprecation", "unchecked" })
	public static void main( String[ ] args ) 
	{
		EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entityManager=emfactory.createEntityManager();
		EntityTransaction et=entityManager.getTransaction();
		et.begin();
		
		PurchaseOrder purchaseOrder = 
		          new PurchaseOrder(111, new java.sql.Date(2011,11,11), 899,"LAptop", new BillingAddress("Broad Street", "Boston", "US", "87654"));

		entityManager.persist( purchaseOrder );
		et.commit();
//fetching records
		List<PurchaseOrder> listPersons = entityManager.createQuery("SELECT p FROM PurchaseOrder p").getResultList();
	   
		et=entityManager.getTransaction();
		et.begin();
	    
	    if (listPersons == null) {
	        System.out.println("No persons found . ");
	    } else {
	        for (PurchaseOrder po  : listPersons) {
	        System.out.print("\n==================\n"
	        		+ po+"\n==================\n");
	        }
	    }
	    et.commit();
		entityManager.close( );		
		emfactory.close( );
	}
}
/*In the above code the createEntityManagerFactory () creates a persistence unit by providing the same unique name which we provide for persistence-unit in persistent.xml file. The entityManagerfactory object will create the entitymanger instance by using createEntityManager () method. The entityManager object creates entitytransaction instance for transaction management. By using entityManager object, we can persist entities into the database.

After compilation and execution of the above program you will get notifications from eclipselink library on the console panel of eclipse IDE.

For result, open the MySQL workbench and type the following queries.
use jpadb
select * from customer
*/