create database corpinfo;
use corpinfo;

CREATE TABLE corporation (id_pk     integer NOT NULL,
                          name      char(255),
                          description TEXT,
                          address   char(255),
                          zipcode   char(16),
                          phone     char(32),
                          PRIMARY KEY (ID_pk))ENGINE=INNODB;

CREATE TABLE employee  (id_pk       integer NOT NULL AUTO_INCREMENT,
                        corp_fk     integer NOT NULL,
                        name        char(255),
                        department  char(64),
                        title       char(64),
                        address     char(255),
                        zipcode     char(16),
                        phone       char(32),
                        PRIMARY KEY (id_pk))ENGINE=INNODB;
ALTER TABLE employee ADD FOREIGN KEY(corp_fk) REFERENCES corporation(id_pk)
ON DELETE CASCADE;

CREATE TABLE corp_award (id_pk   integer   NOT NULL AUTO_INCREMENT,
                         corp_fk integer   NOT NULL,
                         award_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                         -- Define enums as upper case to match the enum in the Java class "AwardValue".
                         value   ENUM('POOR','OK','GOOD','EXCELLENT','GREAT','PERFECT') NOT NULL DEFAULT 'ok',
                         PRIMARY KEY (id_pk))ENGINE=INNODB;
ALTER TABLE corp_award ADD FOREIGN KEY(corp_fk) REFERENCES corporation(id_pk)
ON DELETE CASCADE;

INSERT INTO corporation (id_pk,name,description,address,zipcode,phone) 
       VALUES (1,'Mega Corp','Global industrial multinational corporation','555 Mega Way, Acropolis CA','90266','1-800-555-1211');
INSERT INTO corporation (id_pk,name,description,address,zipcode,phone) 
       VALUES (2,'Super Corp','National industrial corporation','555 Super Way, Acropolis CA','90266','1-877-555-1212');
INSERT INTO corporation (id_pk,name,description,address,zipcode,phone) 
       VALUES (3,'Mini Corp','State industrial corporation','555 Mini Way, Acropolis CA','90266','1-888-555-1213');
INSERT INTO corporation (id_pk,name,description,address,zipcode,phone) 
       VALUES (4,'Stone Corp','Rock Quarry','111 Rock Way, Acropolis CA','90210','1-899-555-1214');

INSERT INTO employee (corp_fk,department,title,name,address,zipcode,phone)
       VALUES (1,'George Castanza','Corporate Officer','CTO','1414 Cherry Lane, Burbsville CA','90266','1-800-555-1213');
INSERT INTO employee (corp_fk,department,title,name,address,zipcode,phone)
       VALUES (1,'Paul Stonehenge','Corporate Officer','CEO','1514 Peachtree Lane, Burbsville CA','90266','1-800-555-1215');
INSERT INTO employee (corp_fk,department,title,name,address,zipcode,phone)
       VALUES (1,'John Watermark','IT','System Admin','1814 Appleseed Drive, Burbsville CA','90266','1-800-555-1218');
INSERT INTO employee (corp_fk,department,title,name,address,zipcode,phone)
       VALUES (4,'Fred Flinstone','Quary Worker','Rock Digger','1814 Appleseed Drive, Burbsville CA','90266','1-800-555-1218');
INSERT INTO employee (corp_fk,department,title,name,address,zipcode,phone)
       VALUES (4,'Wilma Flinstone','Finance','Analyst','1814 Appleseed Drive, Burbsville CA','90266','1-800-555-1218');

INSERT INTO corp_award (corp_fk)       VALUES (1);
INSERT INTO corp_award (corp_fk,value) VALUES (1,'good');
INSERT INTO corp_award (corp_fk,value) VALUES (2,'ok');
INSERT INTO corp_award (corp_fk,value) VALUES (3,'excellent');
INSERT INTO corp_award (corp_fk,value) VALUES (4,'good');
SELECT SLEEP(2);
INSERT INTO corp_award (corp_fk,value) VALUES (4,'excellent');
commit;