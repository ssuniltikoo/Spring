package com.sbk.eclipselinkjpa.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name="corp_award")
public class Award {
    @Id
    @Column(name="id_pk")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer   Id;
    @Column(name="corp_fk")
    private Integer   Corp_fk;
    @Column(name="award_date")
    @Temporal(TemporalType.TIMESTAMP)
    private Date Award_Date;
    // @Column(name="value")
    // [java] Caused by: org.hibernate.HibernateException: Wrong column type in corpinfo.corp_award for column value. Found: enum, expected: varchar(255)
    // The "columnDefinition" fixes this error. Else String expected.
    @Column(name="value",columnDefinition = "ENUM('POOR','OK','GOOD','EXCELLENT','GREAT','PERFECT')")
    @Enumerated(EnumType.STRING)  // Other option is EnumType.ORDINAL which uses a numerical value.
    private AwardValue Value;

    @ManyToOne
    @JoinColumn(name="corp_fk",nullable=false, insertable=false, updatable=false)
    private Corporation corporation;  // Added to support joined query
    public Corporation getCorporation() {
        return corporation;
    }

    public Integer getId() {
        return Id;
    }
    public void setId(Integer _id) {
        this.Id = _id;
    }

    public Integer getCorp_fk() {
        return Corp_fk;
    }
    public void setCorp_fk(Integer _Corp_fk) {
        this.Corp_fk = _Corp_fk;
    }

    public Date getAward_Date() {
        return Award_Date;
    }
    public void setAward_Date(Date _Award_Date) {
        this.Award_Date = _Award_Date;
    }

    public AwardValue getValue() {
        return Value;
    }
    public void setValue(AwardValue _Value) {
        this.Value = _Value;
    }
};