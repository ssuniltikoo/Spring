package com.sbk.eclipselinkjpa.entity;
import java.util.List;
import javax.persistence.*;

public class CorporationDAO {

    public Integer persist(String name, 
                        String description,
                        String address, 
                        String zipcode,
                        String phone)
    {
        EntityManager em = EMgrUtil.getEntityManager();
	EntityTransaction transaction = em.getTransaction();
	Corporation corporation = new Corporation();
	try {
		transaction.begin();
		corporation.setDescription(description);
		corporation.setAddress(address);
		corporation.setZipcode(zipcode);
		corporation.setPhone(phone);
		em.persist(corporation);
		transaction.commit();
	} catch (RuntimeException e) {
		e.printStackTrace();
		transaction.rollback();
	} finally {
		em.close();
	}
	return corporation.getId();
        
    }

    public  void insert ( Corporation c ) {
         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.persist(c);     
        em.getTransaction().commit();
    }
     
    public  void update ( Corporation c ) {
         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.merge(c);       
        em.getTransaction().commit();
    }
     
    public  void deleteById ( Integer id ) {
         
        Corporation c = findById(id);
         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.remove(c);      
        em.getTransaction().commit();
    }
 
    public  List<Corporation> findAll() {
         
        EntityManager em = EMgrUtil.getEntityManager();       
        List<Corporation>  list = em.createQuery(" from Corporation" , Corporation.class).getResultList();       
        return list;
    }
     
    public  Corporation findById(Integer id) {
         
        EntityManager em = EMgrUtil.getEntityManager();
        Corporation corporation = em.find(Corporation.class, id);      
        return corporation;
    }

}