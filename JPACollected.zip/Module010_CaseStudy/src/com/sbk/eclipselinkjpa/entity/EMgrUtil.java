package com.sbk.eclipselinkjpa.entity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
 
public class EMgrUtil {
 
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager        entityManager;
 
    public static EntityManager createEntityManager() {
        if (entityManager == null) {           
          try {
              // com.corpinfo.model is defined in persistence.xml
              entityManagerFactory = Persistence.createEntityManagerFactory("jpa");
              entityManager = entityManagerFactory.createEntityManager();
          } catch(ExceptionInInitializerError e) {
              throw e;
          }
        }
         
        return entityManager;
    }

    public static EntityManagerFactory getEntityManagerFactory() {
        return entityManagerFactory;
    }

    public static EntityManager getEntityManager() {
        return entityManager;
    }

    public static void close() {
        entityManager.close();
        entityManagerFactory.close();
    }
}
/*The goal of this JPA example is to mimic SQL joined select:
mysql> select corporation.name, employee.name from corporation, employee where corporation.id_pk=employee.corp_fk AND corporation.name='Stone Corp';
+------------+-----------------+
| name       | name            |
+------------+-----------------+
| Stone Corp | Fred Flinstone  |
| Stone Corp | Wilma Flinstone |
+------------+-----------------+
Main program to access the database (read/write) including a join between the tables corporation and employee and work with an enumerated type.*/