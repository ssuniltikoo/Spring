package com.sbk.eclipselinkjpa.entity;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="corporation")
public class Corporation {
    @Id                // Tell JPA that id is the primary key
    @Column(name="id_pk")
    private Integer id;

    @Column(name="name",columnDefinition="char(255)")
    private String Name;

    @Column(name="description",length = 65535,columnDefinition="Text")
    private String Description;
    
    @Column(name="address",columnDefinition="char(255)")
    private String Address;

    @Column(name="zipcode",columnDefinition="char(16)")
    private String Zipcode;

    @Column(name="phone",columnDefinition="char(32)")
    private String Phone;

    @OneToMany(cascade=CascadeType.PERSIST,mappedBy="corporation")
    private List<Employee> employees;
    public List<Employee> getEmployees() {return employees;}
    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }

    public Integer getId() {
        return id;
    }
    public void setId(Integer _id) {
        this.id = _id;
    }

    public String getName() {
        return Name;
    }
    public void setName(String _Name) {
        this.Name = _Name;
    }

    public String getDescription() {
        return Description;
    }
    public void setDescription(String _Description) {
        this.Description = _Description;
    }

    public String getAddress() {
        return Address;
    }
    public void setAddress(String _Address) {
        this.Address = _Address;
    }

    public String getZipcode() {
        return Zipcode;
    }
    public void setZipcode(String _Zipcode) {
        this.Zipcode = _Zipcode;
    }

    public String getPhone() {
        return Phone;
    }
    public void setPhone(String _Phone) {
        this.Phone = _Phone;
    }
};