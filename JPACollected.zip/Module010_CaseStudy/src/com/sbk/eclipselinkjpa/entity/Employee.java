package com.sbk.eclipselinkjpa.entity;

import javax.persistence.*;

@Entity
@Table(name="employee_dataType")
public class Employee {
    @Id
    @Column(name="id_pk")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer   Id;

    @Column(name="corp_fk")
    private Integer Corp_fk; // Foreign key to table corporation

    @Column(name="name",columnDefinition="char(255)")
    private String Name;
    @Column(name="department",columnDefinition="char(64)")
    private String Department;
    @Column(name="title",columnDefinition="char(64)")
    private String Title;
    @Column(name="address",columnDefinition="char(255)")
    private String Address;
    @Column(name="zipcode",columnDefinition="char(16)")
    private String Zipcode;
    @Column(name="phone",columnDefinition="char(32)")
    private String Phone;

    // If the @JoinColumn annotation were omitted, a default foreign key is assumed. 
    // The default foreign key name is the name of the attribute in the source entity 
    // (program in our case), followed by an underscore, followed by the primary key 
    // name in the target entity.
    @ManyToOne
    @JoinColumn(name="corp_fk",nullable=false, insertable=false, updatable=false)
    private Corporation corporation;  // Added to support joined query
    public Corporation getCorporation() {
        return corporation;
    }
    public void setCorporation(Corporation corporation) {
        this.corporation = corporation;
    }

    public Integer getId() {
        return Id;
    }
    public void setId(Integer _id) {
        this.Id = _id;
    }

    public Integer getCorp_fk() {
        return Corp_fk;
    }
    public void setCorp_fk(Integer _Corp_fk) {
        this.Corp_fk = _Corp_fk;
    }

    public String getName() {
        return Name;
    }
    public void setName(String _Name) {
        this.Name = _Name;
    }

    public String getDepartment() {
        return Department;
    }
    public void setDepartment(String _Department) {
        this.Department = _Department;
    }

    public String getTitle() {
        return Title;
    }
    public void setTitle(String _Title) {
        this.Title = _Title;
    }

    public String getAddress() {
        return Address;
    }
    public void setAddress(String _Address) {
        this.Address = _Address;
    }

    public String getZipcode() {
        return Zipcode;
    }
    public void setZipcode(String _Zipcode) {
        this.Zipcode = _Zipcode;
    }

    public String getPhone() {
        return Phone;
    }
    public void setPhone(String _Phone) {
        this.Phone = _Phone;
    }
};