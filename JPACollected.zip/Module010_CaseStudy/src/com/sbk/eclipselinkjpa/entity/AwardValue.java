package com.sbk.eclipselinkjpa.entity;
public enum AwardValue {
	   POOR,       // 0
	   OK,         // 1
	   GOOD,       // 2
	   EXCELLENT,  // 3
	   GREAT,      // 4
	   PERFECT     // 5
	}
