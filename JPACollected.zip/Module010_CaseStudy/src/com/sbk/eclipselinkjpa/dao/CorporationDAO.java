package com.sbk.eclipselinkjpa.dao;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.sbk.eclipselinkjpa.entity.Corporation;
import com.sbk.eclipselinkjpa.entity.util.EMgrUtil;

public class CorporationDAO {

    public Integer persist(String name, 
                        String description,
                        String address, 
                        String zipcode,
                        String phone)
    {
        EntityManager em = EMgrUtil.getEntityManager();
	EntityTransaction transaction = em.getTransaction();
	Corporation corporation = new Corporation();
	try {
		transaction.begin();
		corporation.setDescription(description);
		corporation.setAddress(address);
		corporation.setZipcode(zipcode);
		corporation.setPhone(phone);
		em.persist(corporation);
		transaction.commit();
	} catch (RuntimeException e) {
		e.printStackTrace();
		transaction.rollback();
	} finally {
		em.close();
	}
	return corporation.getId();
        
    }

    public  void insert ( Corporation c ) {
    	System.out.println("\n======================================================="
    			+ "\n***********************Inserting**************************"
    			+ "\n======================================================= ");
         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.persist(c);     
        em.getTransaction().commit();
    }
     
    public  void update ( Corporation c ) {
    	System.out.println("\n======================================================="
    			+ "\n***********************Updating**************************"
    			+ "\n======================================================= ");         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.merge(c);       
        em.getTransaction().commit();
    }
     
    public  void deleteById ( Integer id ) {
    	System.out.println("\n======================================================="
    			+ "\n***********************Deleting**************************"
    			+ "\n======================================================= ");         
        Corporation c = findById(id);
         
        EntityManager em = EMgrUtil.getEntityManager();       
        em.getTransaction().begin();       
        em.remove(c);      
        em.getTransaction().commit();
    }
 
    @SuppressWarnings("unchecked")
	public  List<Corporation> findAll() {
    	System.out.println("\n======================================================="
    			+ "\n***********************List of All Objects**************************"
    			+ "\n======================================================= ");         
        EntityManager em = EMgrUtil.getEntityManager();       
        Query query = em.createQuery("SELECT e FROM Corporation e");
        return (List<Corporation>) query.getResultList();
        /*List<Corporation>  list = em.createQuery(" from Corporation" , Corporation.class).getResultList();       
        return list;*/
    }
     
    public  Corporation findById(Integer id) {
    	System.out.println("\n======================================================="
    			+ "\n***********************Finding by Id**************************"
    			+ "\n======================================================= ");        
        EntityManager em = EMgrUtil.getEntityManager();
        Corporation corporation = em.find(Corporation.class, id);      
        return corporation;
    }

}