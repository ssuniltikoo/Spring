package com.sbk.eclipselinkjpa.service;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Level;
import org.apache.log4j.spi.RootLogger;

import com.sbk.eclipselinkjpa.dao.CorporationDAO;
import com.sbk.eclipselinkjpa.entity.Award;
import com.sbk.eclipselinkjpa.entity.Corporation;
import com.sbk.eclipselinkjpa.entity.Employee;
import com.sbk.eclipselinkjpa.entity.util.EMgrUtil;

public class TestDb {
    static{                // Static initializer
        BasicConfigurator.configure();
        RootLogger.getRootLogger().setLevel(Level.WARN);
    }

    @SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception {

        EMgrUtil.createEntityManager(); // Call to static method
        CorporationDAO corpDAO = new CorporationDAO();

        // Add a new record to corporation
        Corporation corporation = new Corporation();
        corporation.setId((int) (1000+new Random().nextDouble()*123.111));//for generating unique id
        corporation.setName("Extra Corp");
        corporation.setDescription("Extra industrial multinational corporation");
        corporation.setAddress("555 Extra Way, Acropolis CA");
        corporation.setZipcode("90267");
        corporation.setPhone("1-800-555-1213");
        corpDAO.insert(corporation);
int corpId=corporation.getId();
        Corporation corp5 = corpDAO.findById(corpId);
        System.out.println("Corp "+corpId+" name: " + corp5.getName() + " Zipcode: " + corp5.getZipcode());

        System.out.println("\nList of Corporations:");
        List<Corporation> corpAll = corpDAO.findAll();
        for(int i = 0; i < corpAll.size(); i++)
        {
            System.out.println("Corp: " + corpAll.get(i).getId() + " " + corpAll.get(i).getName());
        }

        corpDAO.deleteById(corpId);
        System.out.println("\n======================================================="
    			+ "\n***********************Search by  NAme**************************"
    			+ "\n======================================================= ");
        System.out.println("\nQuery result:");
        String sql = "SELECT c FROM Corporation c WHERE c.Name=?1";
        EntityManager entityManager = EMgrUtil.getEntityManager();
        Query query = entityManager.createQuery(sql);
        query.setParameter(1, "Stone Corp");
        Corporation corp = (Corporation)query.getSingleResult();
        System.out.println("Corp name: " + corp.getName());
        System.out.println("\n======================================================="
    			+ "\n***********************All Employees**************************"
    			+ "\n======================================================= ");
        List<Employee> empAll = corp.getEmployees();
        for (Employee employee : empAll) {
           System.out.println("    Employee: " + employee.getName());
        }
        System.out.println("\n======================================================="
    			+ "\n***********************Award**************************"
    			+ "\n======================================================= ");
        String sql2 = "SELECT a FROM Award a WHERE a.Corp_fk=?1 ORDER BY a.Award_Date DESC";
        Query query2 = entityManager.createQuery(sql2);
        query2.setParameter(1, corp.getId());
        List<Award> awards = query2.getResultList();
        System.out.println("    Last corporate rating: " + awards.get(0).getValue());
        System.out.println("\n======================================================="
    			+ "\n***********************Bye Bye :) Thankyou!!**************************"
    			+ "\n======================================================= ");
        EMgrUtil.close();
    }

}