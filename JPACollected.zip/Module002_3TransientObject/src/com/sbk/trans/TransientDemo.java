package com.sbk.trans;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TemporalType;

public class TransientDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		Professor p = new Professor();
		p.setId(new Random().nextInt());
		p.setName("Smita");
		p.setSalary(99999);
		em.persist(p);
		System.out.println("\n======================================================="
				+ "\n************Professor  Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}