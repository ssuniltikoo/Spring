package com.sbk.trans;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SelectDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		System.out.println("\n======================================================="
				+ "\n***********************List of All Professor Objects**************************"
				+ "\n======================================================= ");

		Query query = em.createQuery("SELECT p from Professor p");

		query.getResultList();

		List<Professor> Professors = query.getResultList();

		for (Professor p : Professors) {
			System.out.println(p);
		}
		et.commit();
		em.close();
		System.out.println("Success..!");

	}

}
