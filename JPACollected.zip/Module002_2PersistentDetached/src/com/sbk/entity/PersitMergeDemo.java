package com.sbk.entity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class PersitMergeDemo {

	public static void main(String[] args) {
		Manager manager=new Manager(1000 + new Random().nextInt((int) (11 * 12.123)), "Smita", 123456);
		Address address = new Address("mumbai", "india");
		
		manager.setAddress(address);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(manager);
		Manager manager2=em.find(Manager.class, manager.getId());
	    
		manager2.setName("Brijesh");//no need to insert into db explicitly...it does it automatically
		System.out.println(manager2);
/*Persist and merge are for two different purposes (they aren't alternatives at all).

 persist():
Insert a new register to the database
Attach the object to the entity manager.
 merge():
Find an attached object with the same id and update it.
If exists update and return the already attached object.
If doesn't exist insert the new register to the database.
persist() efficiency:
It could be more efficient for inserting a new register to a database than merge().
It doesn't duplicates the original object.
*/		
		em.merge(manager);
		
		em.detach(manager);/*
		What is detached?
a detached instance is an object that has been persistent, but its Session has been closed. The reference to the object is still valid, of course, and the detached instance might even be modified in this state. A detached instance can be reattached to a new Session at a later point in time, making it (and all the modifications) persistent again. This feature enables a programming model for long running units of work that require user think-time. We call them application transactions, i.e., a unit of work from the point of view of the user.
 Why detached?
The Session caches every object that is in a persistent state (watched and checked for dirty state by Hibernate). If you keep it open for a long time or simply load too much data, it will grow endlessly until you get an OutOfMemoryException. One solution is to call clear() and evict() to manage the Session cache,keeping a Session open for the duration of a user session also means a higher probability of stale data.
*/
		em.persist(manager);
		
		//-------------------------------------------------------------//		
		
		em.remove(manager);
		
		//----------------------------------------------------------//
		
		ArrayList<String> emails=new ArrayList<String>();
		//HashSet<String> emails=new HashSet<String>();
		emails.add("a@gmail.com");
		emails.add("b@gmail.com");
		emails.add("c@gmail.com");
		emails.add("a@gmail.com");
		
		manager.setEmails(emails);
		
		em.persist(manager);
		
		
		//-----------------------------------------------------------//
		
		
		Manager manager3=em.find(Manager.class, manager.getId());
		System.out.println("*******************Manager : "+manager3);
		
		//--------------------------------------------------------//
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
