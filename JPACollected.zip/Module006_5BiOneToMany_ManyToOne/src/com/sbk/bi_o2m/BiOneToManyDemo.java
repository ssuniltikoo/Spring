package com.sbk.bi_o2m;


/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BiOneToManyDemo {

	public static void main(String[] args) {
		Employee employee=new Employee(1111 + new Random().nextInt()+12, "Smita", 123456);
		Address address=new Address(111 + new Random().nextInt()+11, "mum","ind");
		Address address1=new Address(111 + new Random().nextInt()+13, "pune","ind");
		
		ArrayList<Address> addresses=new ArrayList<Address>();
		addresses.add(address);
		addresses.add(address1);
		
		employee.setAddresses(addresses);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(employee);
		//em.persist(address);//two time we have to cal persit if we have not written cascade all
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		System.out.println("Success..!");
		Employee employee2=em.find(Employee.class, employee.getId());
		System.out.println("Employee Found : "+employee2);
		em.close();
		
	}

}
