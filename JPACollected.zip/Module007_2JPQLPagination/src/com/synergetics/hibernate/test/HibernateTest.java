package com.synergetics.hibernate.test;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.synergetics.hibernate.dto.UserDetails;

public class HibernateTest 
{
	public static void main(String[] args) 
	{
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		
		Session session = sessionFactory.openSession();
		
		Transaction transaction = session.beginTransaction();
		
		try 
		{
			/*for (int count = 0; count < 10; count++) 
			{
				UserDetails user = new UserDetails();
				user.setUserName("User_" + count);
				session.save(user);
			}	*/
			
			Query query = session.createQuery("select userName from UserDetails");
			
			//pagination
			query.setFirstResult(5);
//			query.setMaxResults(10);
			
			List<String> list = query.list();
			
			for (String string : list) {
				System.out.println(string);
			}
			
			transaction.commit();
			
		} catch (HibernateException e) 
		{
			
			e.printStackTrace();
			transaction.rollback();
		}
		finally
		{
			session.close();
		}
	}
}
