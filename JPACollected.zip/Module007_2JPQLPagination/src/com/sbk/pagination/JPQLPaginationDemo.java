package com.sbk.pagination;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPQLPaginationDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// em.persist(employee);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Employee employee = new Employee(1000+new Random().nextInt(), "Smita", 123456);
		Address address = new Address("mum", "ind");
		employee.setAddress(address);
		em.merge(employee);
		et.commit();
		/*
		 * Query query = entityManager.createQuery("From Foo"); int pageNumber =
		 * 1; int pageSize = 10; query.setFirstResult((pageNumber-1) *
		 * pageSize); query.setMaxResults(pageSize); List <Foo> fooList =
		 * query.getResultList();
		 */
		String sqlq = "SELECT e FROM Employee e";

		Query query1 = em.createQuery(sqlq);
		/*
		 * setFirstResult(int): Sets the offset position in the result set to
		 * start pagination setMaxResults(int): Sets the maximum number of
		 * entities that should be included in the page
		 */
		// pagination
		int pageNo = 1;
		int pageSize = 10;
		query1.setFirstResult(pageNo);
		query1.setMaxResults(pageSize);
		System.out.println("\n======================================================="
    			+ "\n***********************List of "+pageSize+" pages**************************"
    			+ "\n======================================================= ");         
		List<Employee> employees = query1.getResultList();

		for (Employee emp : employees) {
			System.out.println(emp);
		}

		em.close();
		emf.close();
	}
}
