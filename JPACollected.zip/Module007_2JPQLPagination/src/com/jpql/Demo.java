package com.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Demo {

	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		//em.persist(employee);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		/*Employee employee=new Employee(137, "Smita", 123456);
		Address address=new Address("mum","ind");
		employee.setAddress(address);*/
		//et.commit();
		
		String sqlq="select e.id,e.name from Employee e";
		
		
		Query query1=em.createQuery(sqlq);
		//query.setParameter("city", "ind");
//pagination
		query1.setFirstResult(5);
//		query1.setMaxResults(10);
		List<Object[]> employees=query1.getResultList();
		
		for(Object[] employee2:employees){
			System.out.println(employee2[0]+" "+employee2[1]);
		}
		
	}
}
