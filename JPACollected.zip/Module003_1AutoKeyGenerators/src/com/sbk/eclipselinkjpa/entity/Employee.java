package com.sbk.eclipselinkjpa.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
@Table(name="emp_autokey")
public class Employee implements Serializable {
	@Id
	@GeneratedValue(strategy= GenerationType.AUTO) 
	private int eid;
	private String ename;
	private double salary;
	private String deg;
	private static final long serialVersionUID = 1L;

	public Employee() {
		super();
	}   
	public int getEid() {
		return this.eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}   
	public String getEname() {
		return this.ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}   
	public double getSalary() {
		return this.salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}   
	public String getDeg() {
		return this.deg;
	}

	public void setDeg(String deg) {
		this.deg = deg;
	}
	@Override
	public String toString() {
		return "Employee [eid=" + eid + ", ename=" + ename + ", salary=" + salary + ", deg=" + deg + "]";
	}
   
}
/*In the above code, we have used @Entity annotation to make this POJO class an entity.

Before going to next module we need to create database for relational entity, which will register the database in persistence.xml file. Open MySQL workbench and type hte following query.
create database jpadb
use jpadb

*/