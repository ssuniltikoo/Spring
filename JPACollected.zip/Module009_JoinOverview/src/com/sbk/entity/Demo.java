package com.sbk.entity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(143, "Smita", 123456);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		
		//Employee employee2=em.find(Employee.class, 123);
		Employee employee2=em.find(Employee.class, 143);
	    
		//employee2.setName("Brijesh");//no need to insert into db explicitly...it does it automatically
		System.out.println(employee2);
		
		//em.merge(employee);
		
		//em.detach(employee);
		
		/*em.merge(employee);*/
		/*em.persist(employee);*/
		
		//-------------------------------------------------------------//
		
		/*Address address = new Address("mumbai", "india");
		
		employee.setAddress(address);
		
		em.persist(employee);*/
		//em.remove(employee);
		
		//----------------------------------------------------------//
		
		/*ArrayList<String> set=new ArrayList<String>();
		//HashSet<String> set=new HashSet<String>();
		set.add("a@gmail.com");
		set.add("b@gmail.com");
		set.add("c@gmail.com");
		set.add("a@gmail.com");
		
		employee.setEmails(set);
		
		//em.persist(employee);
		
		
		//-----------------------------------------------------------//
		
		
		Employee employee2=em.find(Employee.class, 137);*/
		
		
		//--------------------------------------------------------//
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
