package com.sbk.uni_m2m;

/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UniManyToManyDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(888 + new Random().nextInt()+11, "Smita", 35000);
		Employee employee2 = new Employee(777 + new Random().nextInt()+13, "Brijesh", 38000);
		Address1 address = new Address1(54 + new Random().nextInt()+11, "mum", "ind");
		Address1 address2 = new Address1(65 + new Random().nextInt()+12, "pune", "ind");

		ArrayList<Employee> list = new ArrayList<Employee>();
		list.add(employee);
		list.add(employee2);

		address.setEmployees(list);
		address2.setEmployees(list);

		// employee.setAddresses(list);
		// employee2.setAddresses(list);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		em.persist(address);
		em.persist(address2);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
