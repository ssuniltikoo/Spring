package com.sbk.uni_m2m;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="employeeUniM2M")
public class Employee {
	@Id
	private int id;
	private String name;
	private int salary;
	
	/*@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="employee_address",joinColumns={@JoinColumn(name="employeeId")},inverseJoinColumns={@JoinColumn(name="addressId")})
	private List<Address> addresses;*/
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}
	
	public Employee(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		
	}

	

/*public void setAddresses(List<Address> addresses) {
	this.addresses = addresses;
}
public List<Address> getAddresses() {
	return addresses;
}*/

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ "]";
	}
	
}