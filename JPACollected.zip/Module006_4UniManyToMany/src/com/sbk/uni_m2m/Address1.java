package com.sbk.uni_m2m;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="addressUniM2M")
public class Address1 {
	@Id
	private int addressId;
	private String city;
	private String country;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="employee_addressUniM2M",joinColumns={@JoinColumn(name="addressId")},inverseJoinColumns={@JoinColumn(name="id")})
	private List<Employee> employees;
	
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	
	public List<Employee> getEmployees() {
		return employees;
	}
	
	public Address1() {
		// TODO Auto-generated constructor stub
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	
	
	
	public Address1(int addressId, String city, String country) {
		super();
		this.addressId = addressId;
		this.city = city;
		this.country = country;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return addressId+" "+city+" "+country;
	}
}
