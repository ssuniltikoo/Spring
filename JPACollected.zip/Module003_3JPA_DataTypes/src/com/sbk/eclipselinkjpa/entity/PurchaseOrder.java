package com.sbk.eclipselinkjpa.entity;

import java.io.Serializable;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * Entity implementation class for Entity: Employee
 *
 */
@Entity
@Table(name = "PURCHASE_ORDERS")
@IdClass(BillingAddress.class)
public class PurchaseOrder {

	PurchaseOrder() {}

	public PurchaseOrder(BillingAddress billingAddress) {
	street = billingAddress.getStreet();
	city = billingAddress.getCity();
	}

	@Id
	@AttributeOverrides({
	@AttributeOverride(name = "street",
	column = @Column(name="STREET")),
	@AttributeOverride(name = "city",
	column = @Column(name="CITY"))
	})

	private String street;
	private String city;
	private String itemName;

	public String getItemName() {
	return itemName;
	}

	public void setItemName(String itemName) {
	this.itemName = itemName;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
}