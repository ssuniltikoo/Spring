package com.synergetics;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Disk disk=new Disk(101, "abc abc");
		AudioDisk audioDisk=new AudioDisk(102, "def def", "album_name");
		VideoDisk videoDisk=new VideoDisk(103, "xyz xyz", "movie_name");
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(disk);
		em.persist(audioDisk);
		em.persist(videoDisk);
		//em.persist(address);

		et.commit();
		em.close();
		System.out.println("Success..!");
		
	}

}
