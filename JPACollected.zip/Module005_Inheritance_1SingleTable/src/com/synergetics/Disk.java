package com.synergetics;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@DiscriminatorColumn(name="DiskType")
@Inheritance(strategy=InheritanceType.SINGLE_TABLE)
@DiscriminatorValue(value="d")
public class Disk {
	
	@Id
	private int id;
	private String desriprtion;
	
	public Disk() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDesriprtion() {
		return desriprtion;
	}

	public void setDesriprtion(String desriprtion) {
		this.desriprtion = desriprtion;
	}

	public Disk(int id, String desriprtion) {
		super();
		this.id = id;
		this.desriprtion = desriprtion;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return desriprtion+" "+id;
	}

}
