package com.synergetics;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class SelectDemo {


	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		javax.persistence.Query query=em.createQuery("from com.lnt.Disk");
		
//		query.getResultList();
		
		List<Disk> disks=query.getResultList();
		
		for(Disk disk:disks){
			
			if(disk instanceof AudioDisk){
				
				AudioDisk audioDisk=(AudioDisk)disk;
				System.out.println(audioDisk);
				
			}else if(disk instanceof VideoDisk){
				VideoDisk videoDisk=(VideoDisk)disk;
				System.out.println(videoDisk);
			}else{
				System.out.println(disk);
			}
			
		}
		
		
		//em.persist(address);

		et.commit();
		em.close();
		System.out.println("Success..!");
		
	}

}
