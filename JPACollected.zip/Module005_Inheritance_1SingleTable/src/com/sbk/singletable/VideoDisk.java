package com.sbk.singletable;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="vd")
public class VideoDisk extends Disk{

	private String movieName;
	
	public VideoDisk() {
		// TODO Auto-generated constructor stub
	}

	public VideoDisk(int id, String desriprtion,String movieName) {
		super(id, desriprtion);
		this.movieName=movieName;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return movieName+" "+super.getDesriprtion()+super.getId();
	}
	
}
