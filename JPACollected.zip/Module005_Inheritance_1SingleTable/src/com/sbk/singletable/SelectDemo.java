package com.sbk.singletable;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SelectDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		System.out.println("\n======================================================="
				+ "\n***********************List of All Objects**************************"
				+ "\n======================================================= ");

		Query query = em.createQuery("SELECT d from Disk d");

		query.getResultList();

		List<Disk> disks = query.getResultList();

		for (Disk disk : disks) {

			if (disk instanceof AudioDisk) {

				AudioDisk audioDisk = (AudioDisk) disk;
				System.out.println(audioDisk);

			} else if (disk instanceof VideoDisk) {
				VideoDisk videoDisk = (VideoDisk) disk;
				System.out.println(videoDisk);
			}

		}
		et.commit();
		em.close();
		System.out.println("Success..!");

	}

}
