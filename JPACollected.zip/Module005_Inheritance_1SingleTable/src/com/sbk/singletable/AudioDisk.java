package com.sbk.singletable;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value="ad")
public class AudioDisk extends Disk{
	
	private String albumName;
	
	public AudioDisk() {
		// TODO Auto-generated constructor stub
	}

	public AudioDisk(int id, String desriprtion,String albumName) {
		super(id, desriprtion);
		this.albumName=albumName;
		// TODO Auto-generated constructor stub
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return albumName+" "+super.getDesriprtion()+" "+super.getId();
	}

}
