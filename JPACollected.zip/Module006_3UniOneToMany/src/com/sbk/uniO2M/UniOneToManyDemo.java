package com.sbk.uniO2M;


/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class UniOneToManyDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(888 + new Random().nextInt()+11, "Smita", 35000);
		Address address = new Address(54 + new Random().nextInt()+11, "mumbai", "ind");
		Address address1 = new Address(65 + new Random().nextInt()+12, "pune", "ind");
		
		ArrayList<Address> addresses=new ArrayList<Address>();
		addresses.add(address);
		addresses.add(address1);
		
		employee.setAddresses(addresses);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(employee);
		//em.persist(address);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
