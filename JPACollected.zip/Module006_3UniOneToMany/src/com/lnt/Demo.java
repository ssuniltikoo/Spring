package com.lnt;


/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Demo {

	public static void main(String[] args) {
		Employee employee=new Employee(137, "ANIKET", 123456);
		Address address=new Address(100, "mum","ind");
		Address address1=new Address(101, "pune","ind");
		
		ArrayList<Address> addresses=new ArrayList<Address>();
		addresses.add(address);
		addresses.add(address1);
		
		employee.setAddresses(addresses);
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(employee);
		//em.persist(address);

		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
