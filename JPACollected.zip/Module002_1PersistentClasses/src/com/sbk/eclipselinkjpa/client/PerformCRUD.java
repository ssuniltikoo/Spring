package com.sbk.eclipselinkjpa.client;

import javax.persistence.EntityManager;

import com.sbk.eclipselinkjpa.entity.Employee;
import com.sbk.eclipselinkjpa.factory.FactoryUtil;
import com.sbk.eclipselinkjpa.service.EmployeeService;
import com.sbk.eclipselinkjpa.service.IEmployeeService;

public class PerformCRUD {

	public static void main(String[] args) {
		// getting instance of entityManager from factory class
		EntityManager entityManager = FactoryUtil.getEntityManagerInstance();
		
		// creating instance of EmployeeService
		IEmployeeService employeeService = new EmployeeService();
		
		// calling createEmployee() Service
		int eid = employeeService.createEmployee(entityManager);
		
		// calling findEmployee() Service
		Employee employee = employeeService.findEmployee(entityManager, eid);
		
		// calling updateEmployee() Service
		employeeService.updateEmployee(entityManager, employee);
		
		// calling deleteEmployee() Service
		employeeService.deleteEmployee(entityManager, employee);
		
		// closing the enitityManagerFactory
		FactoryUtil.closeEnityManagerFactory();
	}

}
