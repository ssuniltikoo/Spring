package com.sbk.eclipselinkjpa.service;

import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.sbk.eclipselinkjpa.entity.Employee;

public class EmployeeService implements IEmployeeService{
	@Override
	public int createEmployee(EntityManager entityManager) {
		EntityTransaction et = entityManager.getTransaction();
		et.begin();
		// now lets perform simple CRUD operation
		// C-create i.e. persist employee object
		Employee employee = new Employee();
		employee.setEid(1000 + new Random().nextInt((int) (11 * 12.123)));
		employee.setEname("Smita B Kumar");
		employee.setSalary(99999);
		employee.setDeg("Technical Trainer");
		// entityManager.merge( employee );
		entityManager.persist(employee);
		et.commit();
		int eid=employee.getEid();
		employee = entityManager.find(Employee.class,eid );
		if (employee == null) {
			System.out.println("\n==========================================="
					+ "\n*******Employee Not Created/Persisted *******"
					+ "\n===========================================\n");
		} else {
			System.out.println(
					"\n==========================================================="
					+ "\n*******Employee Created with Employee Id :"+eid+"*******"
					+ "\n===========================================================\n");
		}
		return eid;
	}

	// R-Retrieve i.e. find employee object
	@Override
	public Employee findEmployee(EntityManager entityManager, int eid) {

		Employee employee = entityManager.find(Employee.class, eid);
		if (employee == null) {
			System.out.println(
					"\n==========================================="
					+ "\n*******Employee Does Not exits*******"
					+ "\n===========================================\n");
		} else {
			System.out.println(
					"\n==========================================="
					+ "\n*******Employee Found!!*******"
					+ "\n===========================================\n");
		
			System.out.println("employee ID = " + employee.getEid());
			System.out.println("employee NAME = " + employee.getEname());
			System.out.println("employee SALARY = " + employee.getSalary());
			System.out.println("employee DESIGNATION = " + employee.getDeg());
		}
		return employee;
	}

	// U-Update i.e. modify employee object
	@Override
	public void updateEmployee(EntityManager entitymanager, Employee employee) {
		entitymanager.getTransaction().begin();
		employee = entitymanager.find(Employee.class, employee.getEid());
		// before update
		if (employee == null) {
			System.out.println(
					"\n==========================================="
					+ "\n*******Employee Does Not exits*******\n"
					+ "===========================================\n");
		} else {
			System.out.println("\n==========================================="
					+ "\n*******Before Update*******\n"
					+ "===========================================\n");
			System.out.println(employee);

			employee.setSalary(46000);
			entitymanager.getTransaction().commit();
			// after update
			System.out.println("\n==========================================="
					+ "\n*******After Update*******"
					+ "\n===========================================\n");
			System.out.println(employee);
		}
	}

	// D-Delete i.e. remove employee object
	@Override
	public void deleteEmployee(EntityManager entityManager, Employee employee) {

		entityManager.getTransaction().begin();
		employee = entityManager.find(Employee.class, employee.getEid());
		if (employee == null) {
			System.out.println(
					"\n==========================================="
					+ "\n*******Employee Does Not exits*******"
					+ "\n===========================================\n");
		} else {
			entityManager.remove(employee);
			System.out.println(
					"\n==========================================="
					+ "\n*******Employee Deleted*******"
					+ "\n===========================================\n");
		
		}
		entityManager.getTransaction().commit();
	}
}
/*
 * In the above code the createEntityManagerFactory () creates a persistence
 * unit by providing the same unique name which we provide for persistence-unit
 * in persistent.xml file. The entityManagerfactory object will create the
 * entitymanger instance by using createEntityManager () method. The
 * entityManager object creates entitytransaction instance for transaction
 * management. By using entityManager object, we can persist entities into the
 * database.
 * 
 * After compilation and execution of the above program you will get
 * notifications from eclipselink library on the console panel of eclipse IDE.
 * 
 * For result, open the MySQL workbench and type the following queries. use
 * jpadb select * from employee
 */