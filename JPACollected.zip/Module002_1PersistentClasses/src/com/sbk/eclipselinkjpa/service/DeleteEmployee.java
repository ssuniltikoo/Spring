package com.sbk.eclipselinkjpa.service;
/*Deleting Employee

To delete the records of an employee, first we will find the existing records and then delete it. Here EntityTransaction plays an important role.

The class named DeleteEmployee.java as follows:
*/

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sbk.eclipselinkjpa.entity.Employee;

public class DeleteEmployee 
{
	public static void main( String[ ] args ) 
	{
		EntityManagerFactory emfactory = Persistence.
				createEntityManagerFactory( "jpa" );
		EntityManager entitymanager = emfactory.
				createEntityManager( );
		entitymanager.getTransaction( ).begin( );
		Employee employee=entitymanager.
				find( Employee.class, 10011 );
		if(employee==null){System.out.println("=====Employee Does Not exits=====");}
		else{
			entitymanager.remove( employee );
		}
		entitymanager.getTransaction( ).commit( );
		entitymanager.close( );
		emfactory.close( );
	}
}
/*
After compilation and execution of the above program you will get notifications from Eclipselink library on the console panel of eclipse IDE.

For result, open the MySQL workbench and type the following queries.
use jpadb
select * from employee

The effected database named employee will have null records.
*/