package com.sbk.eclipselinkjpa.service;

/*To update the records of an employee, we need to retrieve the existing records form the database, make changes, and finally commit it to the database. The class named UpdateEmployee.java is shown as follows:*/


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.sbk.eclipselinkjpa.entity.Employee;

public class UpdateEmployee 
{
	public static void main( String[ ] args ) 
	{
		EntityManagerFactory emfactory = Persistence.
				createEntityManagerFactory( "jpa" );
		EntityManager entitymanager = emfactory.
				createEntityManager( );
				entitymanager.getTransaction( ).begin( );
		Employee employee=entitymanager.
				find( Employee.class, 10011 );
		//before update
		if(employee==null){System.out.println("=====Employee Does Not exits=====");}
		else{
			System.out.println("====Before Update=====");
			System.out.println( employee );
		
			employee.setSalary( 46000 );
			entitymanager.getTransaction( ).commit( );
	        //after update
			System.out.println("====After Update=====");
			System.out.println( employee );
		}
		entitymanager.close();
		emfactory.close();
	}
}

/*After compilation and execution of the above program you will get notifications from Eclipselink library on the console panel of eclipse IDE.

For result, open the MySQL workbench and type the following queries.
use jpadb
select * from employee
*/