package com.sbk.eclipselinkjpa.service;

import javax.persistence.EntityManager;

import com.sbk.eclipselinkjpa.entity.Employee;

public interface IEmployeeService {

	int createEmployee(EntityManager entityManager);

	Employee findEmployee(EntityManager entityManager, int eid);

	void updateEmployee(EntityManager entitymanager, Employee employee);

	void deleteEmployee(EntityManager entityManager, Employee employee);

}
