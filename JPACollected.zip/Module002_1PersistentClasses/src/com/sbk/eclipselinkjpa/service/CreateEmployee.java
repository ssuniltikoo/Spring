package com.sbk.eclipselinkjpa.service;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.sbk.eclipselinkjpa.entity.Employee;

public class CreateEmployee 
{
	public static void main( String[ ] args ) 
	{
		EntityManagerFactory emfactory=Persistence.createEntityManagerFactory("jpa");
		EntityManager entitymanager=emfactory.createEntityManager();
		EntityTransaction et=entitymanager.getTransaction();
		et.begin();
		
		Employee employee = new Employee( ); 
		employee.setEid( 10011 );
		employee.setEname( "Smita B Kumar" );
		employee.setSalary( 99999 );
		employee.setDeg( "Technical Trainer" );
		//entitymanager.merge( employee );
		entitymanager.persist( employee );
		et.commit();
		
		entitymanager.close( );		
		emfactory.close( );
	}
}
/*In the above code the createEntityManagerFactory () creates a persistence unit by providing the same unique name which we provide for persistence-unit in persistent.xml file. The entitymanagerfactory object will create the entitymanger instance by using createEntityManager () method. The entitymanager object creates entitytransaction instance for transaction management. By using entitymanager object, we can persist entities into the database.

After compilation and execution of the above program you will get notifications from eclipselink library on the console panel of eclipse IDE.

For result, open the MySQL workbench and type the following queries.
use jpadb
select * from employee
*/