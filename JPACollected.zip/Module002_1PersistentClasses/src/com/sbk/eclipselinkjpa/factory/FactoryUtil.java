package com.sbk.eclipselinkjpa.factory;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnitUtil;

public class FactoryUtil {
	private static EntityManager entityManagerInstance;
	private static EntityManagerFactory emfactory;
	public static EntityManager getEntityManagerInstance() {
		if (entityManagerInstance == null) {
			emfactory = Persistence.createEntityManagerFactory("jpa");
			entityManagerInstance = emfactory.createEntityManager();
		}
		return entityManagerInstance;
	}
	public static void closeEnityManagerFactory(){	
		if (entityManagerInstance != null) 
		emfactory.close( );
	}
}
