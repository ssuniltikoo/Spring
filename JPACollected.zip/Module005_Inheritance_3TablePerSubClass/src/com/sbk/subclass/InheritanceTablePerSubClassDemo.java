package com.sbk.subclass;

import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class InheritanceTablePerSubClassDemo {

	/**
	 * @author Smita
	 */
	public static void main(String[] args) {
		Disk disk = new Disk(100 + new Random().nextInt() * 12, "asdf");
		AudioDisk audioDisk = new AudioDisk(100 + new Random().nextInt() * 12, "awrear", "ebrnj");
		VideoDisk videoDisk = new VideoDisk(111 + new Random().nextInt() * 18, "dsroh", "eothj");

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		em.persist(disk);
		em.persist(audioDisk);
		em.persist(videoDisk);

		et.commit();
		System.out.println("\n======================================================="
				+ "\n************Disk,AudioDisk ANd VideoDisk Persisted***************"
				+ "\n======================================================= ");
		em.close();
		System.out.println("Success..!");
	}

}