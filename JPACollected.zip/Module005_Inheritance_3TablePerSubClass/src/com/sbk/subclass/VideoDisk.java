package com.sbk.subclass;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="VideoDisk_subclass")
@PrimaryKeyJoinColumn(referencedColumnName="id")
public class VideoDisk extends Disk{

	private String movieName;
	
	public VideoDisk() {
		// TODO Auto-generated constructor stub
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	
	public String getMovieName() {
		return movieName;
	}
	
	public VideoDisk(int id, String desriprtion,String movieName) {
		super(id, desriprtion);
		this.movieName=movieName;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return movieName+" "+super.getDescription()+super.getId();
	}
	
}
