package com.sbk.subclass;

import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="AudioDisk_subclass")
@PrimaryKeyJoinColumn(referencedColumnName="id")
public class AudioDisk extends Disk{
	
	private String albumName;
	
	public AudioDisk() {
		// TODO Auto-generated constructor stub
	}

	public AudioDisk(int id, String desriprtion,String albumName) {
		super(id, desriprtion);
		this.albumName=albumName;
		// TODO Auto-generated constructor stub
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return albumName+" "+super.getDescription()+" "+super.getId();
	}

}
