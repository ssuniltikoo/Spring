package com.synergetics;



import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class Demo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Employee employee1=new Employee(123,"Smita",100000);
		Disk disk=new Disk(1, "asdf");
		AudioDisk audioDisk=new AudioDisk(2, "awrear", "ebrnj");
		VideoDisk videoDisk=new VideoDisk(21, "dsroh", "eothj");

		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		
		em.persist(disk);
		em.persist(audioDisk);
		em.persist(videoDisk);
		//em.persist(address);

		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}