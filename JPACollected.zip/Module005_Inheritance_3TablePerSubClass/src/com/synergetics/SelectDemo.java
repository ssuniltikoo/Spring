package com.synergetics;

import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SelectDemo {


	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	Configuration configuration=new Configuration();
		
		configuration=configuration.configure();
		
		SessionFactory sessionFactory=configuration.buildSessionFactory();
		
		Session session=sessionFactory.openSession();
		
		session.beginTransaction();
		
		org.hibernate.Query query=session.createQuery("from Disk");
		
		
//		query.getResultList();
		List<Disk> disks=query.list();
		
		
		for(Disk disk:disks){
			
			if(disk instanceof AudioDisk){
				
				AudioDisk audioDisk=(AudioDisk)disk;
				System.out.println(audioDisk);
				
			}else if(disk instanceof VideoDisk){
				VideoDisk videoDisk=(VideoDisk)disk;
				System.out.println(videoDisk);
			}else{
				System.out.println(disk);
			}
			
		}
		
		
		//em.persist(address);
		session.getTransaction().commit();
	
		
		sessionFactory.close();
		
		System.out.println("Success..!");
		
	}

}
