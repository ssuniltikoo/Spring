package com.sbk.collection;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class WorkingWithCollectionsDemo {

	public static void main(String[] args) {
		Employee e = new Employee();
		e.setName("Smita");

		Department d = new Department();
		d.addEmployee(e);
		d.setName("Training");

		e.setDepartment(d);

		d.addEmployee(e);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		em.persist(d);
		em.persist(e);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Department Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
