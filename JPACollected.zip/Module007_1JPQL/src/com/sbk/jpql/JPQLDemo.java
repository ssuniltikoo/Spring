package com.sbk.jpql;

import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class JPQLDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		Employee employee = new Employee(1000 + new Random().nextInt(), "Smita", 35000);
		Address address = new Address("mum", "ind");
		employee.setAddress(address);
		em.persist(employee);
		et.commit();
		System.out.println("\n======================================================="
    			+ "\n***********************Employee Persisted**************************"
    			+ "\n======================================================= ");
		String sqlq = "select e.id,e.name from Employee e";

		Query query1 = em.createQuery(sqlq);
		// query1.setParameter("city", "ind");

		List<Object[]> employees = query1.getResultList();
		System.out.println("\n======================================================="
    			+ "\n***********************List of Employees**************************"
    			+ "\n======================================================= ");
		for (Object[] employee2 : employees) {
			System.out.println(employee2[0] + " " + employee2[1]);
		}

		// Scalar function-Scalar functions returns resultant values based on
		// input values. Aggregate functions returns the resultant values by
		// calculating the input values.

		Query query2 = em.createQuery("Select UPPER(e.name) from Employee e");
		List<String> list = query2.getResultList();
		System.out.println("\n======================================================="
    			+ "\n*******List of Employees Using SACALAR FUNCTION*******"
    			+ "\n======================================================= ");
		for (String e : list) {
			System.out.println("Employee NAME :" + e);
		}

		/*
		 * Aggregate function-Scalar functions returns resultant values based on
		 * input values. Aggregate functions returns the resultant values by
		 * calculating the input values.
		 */
		Query query3 = em.createQuery("Select MAX(e.salary) from Employee e");
		Integer result = (Integer) query3.getSingleResult();
		System.out.println("\n======================================================="
    			+ "\n*******AGGREGATE FUNCTION*******"
    			+ "\n======================================================= ");
		System.out.println("Max Employee Salary :" + result);

		// Between-�Between�, �And�, and �Like� are the main keywords of
		// JPQL. // These keywords are used after Where clause in a query. Query
		Query query4 = em.createQuery("Select e " + "from Employee e " + "where e.salary " + "Between 30000 and 40000");

		List<Employee> list1 = (List<Employee>) query4.getResultList();
		System.out.println("\n======================================================="
    			+ "\n*******List of Employees Using BETWEEN*******"
    			+ "\n======================================================= ");
		for (Employee e : list1) {
			System.out.print("Employee ID :" + e.getId());
			System.out.println("\t Employee salary :" + e.getSalary());
		}

		// Like-�Between�, �And�, and �Like� are the main keywords of JPQL.
		// These keywords are used after Where clause in a query. Query
		Query query5 = em.createQuery("Select e " + "from Employee e " + "where e.name LIKE 'S%'");
		System.out.println("\n======================================================="
    			+ "\n*******List of Employees Using LIKE*******"
    			+ "\n======================================================= ");
		List<Employee> list2 = (List<Employee>) query5.getResultList();

		for (Employee e : list2) {
			System.out.print("Employee ID :" + e.getId());
			System.out.println("\t Employee name :" + e.getName());
		}
		// ORDER BY-To Order the records in JPQL we use ORDER BY clause. The
		// usage of this clause is same as the use in SQL, but it deals with
		// entities.
		System.out.println("\n======================================================="
    			+ "\n*******List of Employees Using ORDER BY*******"
    			+ "\n======================================================= ");
		Query query6 = em.createQuery("Select e " + "from Employee e " + "ORDER BY e.name ASC");

		List<Employee> list3 = (List<Employee>) query6.getResultList();

		for (Employee e : list3) {
			System.out.print("Employee ID :" + e.getId());
			System.out.println("\t Employee Name :" + e.getName());
		}

		em.close();
		System.out.println("\n======================================================="
    			+ "\n*******THANK YOU !!!*******"
    			+ "\n======================================================= ");

	}
}
