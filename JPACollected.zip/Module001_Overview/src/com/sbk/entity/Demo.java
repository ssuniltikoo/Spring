package com.sbk.entity;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Demo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence
		        .createEntityManagerFactory("jpa");
		    EntityManager em = emf.createEntityManager();
		    EmployeeService service = new EmployeeService(em);

		    em.getTransaction().begin();
		    Employee emp = service.createEmployee(1+new Random().nextInt(11), "Smita", 5000);
		    em.getTransaction().commit();
		    System.out.println("************Persisted " + emp);

		    emp = service.findEmployee(1);
		    System.out.println("************Found " + emp);

		    List<Employee> emps = service.findAllEmployees();
		    for (Employee e : emps)
		      System.out.println("************Found employee: " + e);

		    em.getTransaction().begin();
		    emp = service.raiseEmployeeSalary(1, 1000);
		    em.getTransaction().commit();
		    System.out.println("************Updated " + emp);

		    em.getTransaction().begin();
		    service.removeEmployee(158);
		    em.getTransaction().commit();
		    System.out.println("************Removed Employee 158");

		    em.close();
		    emf.close();
	}

}
