package com.sbk.table_per_class;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="AudioDisk_perclass")
@AttributeOverrides({  
    @AttributeOverride(name="id", column=@Column(name="id")),  
    @AttributeOverride(name="desriprtion", column=@Column(name="desriprtion"))  
})  
public class AudioDisk extends Disk{
	
	private String albumName;
	
	public AudioDisk() {
		// TODO Auto-generated constructor stub
	}

	public AudioDisk(int id, String desriprtion,String albumName) {
		super(id, desriprtion);
		this.albumName=albumName;
		// TODO Auto-generated constructor stub
	}

	public String getAlbumName() {
		return albumName;
	}

	public void setAlbumName(String albumName) {
		this.albumName = albumName;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return albumName+" "+super.getDesriprtion()+" "+super.getId();
	}

}
