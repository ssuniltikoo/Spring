package com.synergetics;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@AttributeOverrides({  
    @AttributeOverride(name="id", column=@Column(name="id")),  
    @AttributeOverride(name="desriprtion", column=@Column(name="desriprtion"))  
})  
public class VideoDisk extends Disk{

	private String movieName;
	
	public VideoDisk() {
		// TODO Auto-generated constructor stub
	}

	public VideoDisk(int id, String desriprtion,String movieName) {
		super(id, desriprtion);
		this.movieName=movieName;
		// TODO Auto-generated constructor stub
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return movieName+" "+super.getDesriprtion()+super.getId();
	}
	
}
