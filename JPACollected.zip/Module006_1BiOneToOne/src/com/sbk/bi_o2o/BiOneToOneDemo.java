package com.sbk.bi_o2o;


import java.util.Random;

/*import java.util.ArrayList;*/
/*import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
*/
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class BiOneToOneDemo {

	public static void main(String[] args) {
		Employee employee = new Employee(888 + new Random().nextInt()+11, "Smita", 35000);
		Address address = new Address(54 + new Random().nextInt()+11, "mumbai", "ind");
		employee.setAddress(address);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		em.persist(employee);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
		/*EntityManagerFactory emf=Persistence.createEntityManagerFactory("jpa");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		et.begin();
		em.persist(employee);
		//em.persist(address);
		System.out.println("\n======================================================="
				+ "\n************Employee ANd Address Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");*/
	}

}
