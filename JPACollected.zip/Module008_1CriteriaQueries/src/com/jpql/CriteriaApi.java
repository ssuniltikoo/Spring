package com.jpql;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

public class CriteriaApi {
	   public static void main(String[] args) {
	   
	   EntityManagerFactory emfactory = Persistence.createEntityManagerFactory( "jpa" );
	   EntityManager entitymanager = emfactory.createEntityManager( );
	   CriteriaBuilder criteriaBuilder = entitymanager.getCriteriaBuilder();
	   CriteriaQuery<Object> criteriaQuery = criteriaBuilder.createQuery();
	   Root<Employee> from = criteriaQuery.from(Employee.class);

	   //select all records
	   System.out.println("Select all records");
	   CriteriaQuery<Object> select = criteriaQuery.select(from);
	   TypedQuery<Object> typedQuery = entitymanager.createQuery(select);
	   List<Object> resultlist = typedQuery.getResultList();

	   for(Object o:resultlist) {
	      Employee e = (Employee)o;
	      System.out.println("EID : " + e.getEid() + " Ename : " + e.getEname());
	   }

	   //Ordering the records 
	   System.out.println("Select all records by follow ordering");
	   CriteriaQuery<Object> select1 = criteriaQuery.select(from);
	   select1.orderBy(criteriaBuilder.asc(from.get("ename")));
	   TypedQuery<Object> typedQuery1 = entitymanager.createQuery(select);
	   List<Object> resultlist1 = typedQuery1.getResultList();

	   for(Object o:resultlist1){
	      Employee e=(Employee)o;
	      System.out.println("EID : " + e.getEid() + " Ename : " + e.getEname());
	   }
//get single result
	   TypedQuery<Long> query = entitymanager.createQuery(
			      "SELECT COUNT(c) FROM Employee e", Long.class);
			  long empCount = query.getSingleResult();
			  System.out.println("Employee Count is  :"+empCount);
	   
//DELETE and UPDATE Query Execution (with executeUpdate)
			  ///Selective Update
			  Query query2 = entitymanager.createQuery(
				      "UPDATE Employee e SET salary = salary * 11 / 100 " +
				      "WHERE e.salary < :s");
				  int updateCount = query2.setParameter(1,10000).executeUpdate();
			//Update All Queries	  
			  Query query3 = entitymanager.createQuery("UPDATE Employee e SET salary = salary * 11 / 100 ");
				  updateCount = query3.executeUpdate();
			//Delete
	   int countDel = entitymanager.createQuery("DELETE FROM Employee").executeUpdate();
	   entitymanager.close( );
	   emfactory.close( );
	   }
}
