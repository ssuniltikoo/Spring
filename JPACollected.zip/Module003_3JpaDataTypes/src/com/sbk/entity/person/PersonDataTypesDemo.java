package com.sbk.entity.person;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TemporalType;

public class PersonDataTypesDemo {

	public static void main(String[] args) {
		Person p = new Person("Smita", "B Kumar");
		p.setId(new Random().nextLong() + 11);
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();

		em.persist(p);
		System.out.println("\n======================================================="
				+ "\n************Person  Persisted***************"
				+ "\n======================================================= ");
		et.commit();

		em.close();
		System.out.println("Success..!");
	}

}
