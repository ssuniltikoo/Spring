package com.sbk.entity.person;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SelectPersonDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();
		et.begin();
		System.out.println("\n======================================================="
				+ "\n***********************List of All Person Objects**************************"
				+ "\n======================================================= ");

		Query query = em.createQuery("SELECT p from Person p");

		query.getResultList();

		List<Person> persons = query.getResultList();

		for (Person person : persons) {
			System.out.println(person);
		}
		et.commit();

		em.close();
		System.out.println("Success..!");

	}

}
