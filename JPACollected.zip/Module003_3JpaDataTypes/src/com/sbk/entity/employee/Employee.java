package com.sbk.entity.employee;

import java.util.Calendar;
import java.util.Date;

/*
JPA Column Definition
JPA Column Name
JPA Column Length
JPA Column Precision Scale
JPA Column Unique Nullable
JPA Date Column
JPA Calendar Date
JPA Map Date to Time
JPA Map Date to Timestamp
JPA Transient
 */
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "Employee_dataType")
public class Employee {

	@Id // Tell JPA that id is the primary key
	@Column(name = "id_pk")
	private Integer id;

	@Column(name = "name", columnDefinition = "long", unique = true, nullable = false) // unique and not null
	private String name;

	@Column(name = "description", length = 65535, columnDefinition = "long") // length for size of column-data
	private String description;

	@Column(name = "address", columnDefinition = "long")
	private String address;

	@Column(name = "zipcode", columnDefinition = "long")
	private String zipcode;

	@Column(name = "phone", columnDefinition = "long")
	private String phone;

	@Column(precision = 8, scale = 2)
	private float hourlyRate;
	/*
	 * Date time=Calendar.getInstance().getTime();//TemporalType.TIME Calendar
	 * dob=Calendar.getInstance();//TemporalType.DATE Date
	 * doj=Calendar.getInstance().getTime();;//TemporalType.TIMESTAMP
	 * java.sql.Date startDate=new java.sql.Date(System.currentTimeMillis());
	 */
	@Temporal(TemporalType.TIME) // time of registration
	private java.util.Date time;

	/*@Temporal(TemporalType.DATE)
	private java.util.Calendar dob;
	// or
	@Temporal(TemporalType.TIMESTAMP) // timestamp
	private java.util.Date doj;// date of joining

	// or CURRENT SYSTEM DATE
	@Column(name = "START_DATE", columnDefinition = "DATE DEFAULT CURRENT_DATE")
	private java.sql.Date startDate;// registration system date and time
*/
	@Transient
	private String password;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		zipcode = zipcode;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public float getHourlyRate() {
		return hourlyRate;
	}

	public void setHourlyRate(float hourlyRate) {
		this.hourlyRate = hourlyRate;
	}

	public java.util.Date getTime() {
		return time;
	}

	public void setTime(java.util.Date time) {
		this.time = time;
	}

	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Employee() {

	}

	public Employee(Integer id, String name, String description, String address, String zipcode, String phone,
			float hourlyRate, Date time, String password) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.address = address;
		this.zipcode = zipcode;
		this.phone = phone;
		this.hourlyRate = hourlyRate;
		this.time = time;
		this.password = password;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", description=" + description + ", address=" + address
				+ ", Zipcode=" + zipcode + ", phone=" + phone + ", hourlyRate=" + hourlyRate + ", time=" + time
				+ ", password=" + password + "]";
	}

	/*public Employee(Integer id, String name, String description, String address, String zipcode, String phone,
			float hourlyRate, Date time, Calendar dob, Date doj, java.sql.Date startDate, String password) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.address = address;
		this.zipcode = zipcode;
		this.phone = phone;
		this.hourlyRate = hourlyRate;
		this.time = time;
		this.dob = dob;
		this.doj = doj;
		this.startDate = startDate;
		this.password = password;
	}
*/
	

};