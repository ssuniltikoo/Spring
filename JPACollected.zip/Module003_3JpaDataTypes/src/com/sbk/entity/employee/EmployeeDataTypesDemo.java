package com.sbk.entity.employee;

import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TemporalType;

public class EmployeeDataTypesDemo {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("jpa");
		EntityManager em = emf.createEntityManager();
		EntityTransaction et = em.getTransaction();

		et.begin();
		java.util.Date time = Calendar.getInstance().getTime();// TemporalType.TIME
		/*java.util.Calendar dob = Calendar.getInstance();// TemporalType.DATE
		java.util.Date doj = Calendar.getInstance().getTime();		// TemporalType.TIMESTAMP
		java.sql.Date startDate = new java.sql.Date(System.currentTimeMillis());// columnDefinition
																				// =
																				// "DATE
																				// DEFAULT
																				// CURRENT_DATE"
*/		/*
		 * public Employee(Integer id, String name, String description, String
		 * address, String zipcode, String phone, float hourlyRate, Date time,
		 * Calendar dob, Date doj, java.sql.Date startDate, String password)
		 */
		/*Employee e = new Employee(111, "Smita", "Consultant", "mumbai", "400708", "9876567890",
				2.2f,time,dob, doj, startDate, "smita@123" );*/
		Employee e = new Employee(111, "Smita", "Consultant", "mumbai", "400708", "9876567890",
				2.2f,time, "smita@123");
		em.persist(e);
		System.out.println("\n======================================================="
				+ "\n************Employee  Persisted***************"
				+ "\n======================================================= ");
		et.commit();
		em.close();
		System.out.println("Success..!");
	}

}
