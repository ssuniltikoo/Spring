/*
 * public Employee(Integer id, String name, String description, String address, String zipcode, String phone,
			float hourlyRate, Date time, Calendar dob, Date doj, java.sql.Date startDate, String password) {
	
 */
CREATE TABLE employee  (id_pk       integer NOT NULL AUTO_INCREMENT,
                        corp_fk     integer NOT NULL,
                        name        varchar(255),
                        description  varchar(64),
                        title       char(64),
                        address     char(255),
                        zipcode     char(16),
                        phone       char(32),
                        PRIMARY KEY (id_pk))ENGINE=INNODB;
