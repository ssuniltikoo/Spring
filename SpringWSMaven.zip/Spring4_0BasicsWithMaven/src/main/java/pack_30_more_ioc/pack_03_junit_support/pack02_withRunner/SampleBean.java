package pack_30_more_ioc.pack_03_junit_support.pack02_withRunner;

public class SampleBean {

	public String sampleMethod() {
		return ("Sample method");
	}
}
