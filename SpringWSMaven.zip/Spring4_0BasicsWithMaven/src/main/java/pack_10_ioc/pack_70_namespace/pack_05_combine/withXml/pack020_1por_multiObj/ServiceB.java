package pack_10_ioc.pack_70_namespace.pack_05_combine.withXml.pack020_1por_multiObj;

public class ServiceB {
	private String value3; 
	private String value4; 
	
	public ServiceB(){
		
	}

	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}

	@Override
	public String toString() {
		return "ServiceB [value3=" + value3 + ", value4=" + value4 + "]";
	}
}
