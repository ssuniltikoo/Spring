package pack_10_ioc.pack_70_namespace.pack_05_combine.withXml.pack010_1ph_multiObj;

public class ServiceB {
	private String value3;
	private String value4;
	private String value5;
	
	public ServiceB(){
		
	}
	
	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}
	public void setValue5(String value5) {
		this.value5 = value5;
	}

	@Override
	public String toString() {
		return "Service2 [value3=" + value3 + ", value4=" + value4
				+ ", value5=" + value5 + "]";
	}
}
