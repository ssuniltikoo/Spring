package pack_10_ioc.pack_20_moreOnBeans.pack_04_autowiring.pack_30_wireAnnot;

public interface IGlobInvestment {
	public String getFirmName();
}
