package pack_40_aop.pack_20_pointcut.pack_service;

public interface OrderService {

	public void placeOrder(Order order);

}