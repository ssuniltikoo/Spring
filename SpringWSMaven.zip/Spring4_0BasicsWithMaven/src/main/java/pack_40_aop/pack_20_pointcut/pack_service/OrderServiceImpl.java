package pack_40_aop.pack_20_pointcut.pack_service;

public class OrderServiceImpl implements OrderService {

	public void placeOrder(Order order) {
		//some order processing logic here
	}
}
