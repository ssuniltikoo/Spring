package pack_40_aop.pack_20_pointcut.pack_service;

public class Order {

	@Override
	public String toString(){
		return "I am in Order";
	}
}
