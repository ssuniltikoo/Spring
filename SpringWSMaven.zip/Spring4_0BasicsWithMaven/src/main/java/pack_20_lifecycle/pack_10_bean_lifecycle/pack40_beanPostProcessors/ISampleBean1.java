package pack_20_lifecycle.pack_10_bean_lifecycle.pack40_beanPostProcessors;

public interface ISampleBean1 {
	String toString();
}
